/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package menu;

import javax.swing.JOptionPane;

/**
 *
 * @author Nhlamulo G Hlatywayo
 */
public class Menu {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*1) Biltong R57.50 582647
        2) Mageu  R19.00 777788
        3) Doritos R48.90 75869741
        4) Top Deck R33.00 78597415
        */
         double []prices=new double[4];
         String names[] = new String[4];
         int[] batch = new int[4];
         
         //Prices of  products
         prices[0]= 57.50;
         prices[0]= 19.00;
         prices[0]= 48.90;
         prices[0]= 33.00;
         
      //Names of products  
         names[0]="Biltong";
         names[0]="Mageu"; 
         names[0]="Doritos";
         names[0]="Top Deck";
         
         //Batch numbers of products
         batch[0]=582647;
         batch[1]=7777885;
         batch[2]=75869741;
         batch[3]=78597415;
         
         //Search and print product with name Top Deck
         for(int i=0;i < names.length; i++){
             if(names[i].equals("Top Deck")) {
                 JOptionPane.showMessageDialog(null, "Product Report\n" +
                         "NAME: " + names[i]+"\n"+
                         "PRICE: R " + prices[i] + "\n"+
                         "BATCH: " + batch[i]);
             }
         }
    }
    
}
